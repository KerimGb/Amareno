<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Configuration for favorite sections that are implemented via shortcode
 *
 * @return array
 */
return array(
	'hide_on_adding_list' => TRUE,
	'as_child' => array(
		'only' => 'container',
	),
);
